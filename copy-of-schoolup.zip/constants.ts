
export const ZAMBIAN_GRADES = [
  'Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6', 'Grade 7',
  'Grade 8', 'Grade 9', 'Grade 10', 'Grade 11', 'Grade 12'
];

export const TERMS = [1, 2, 3];

export const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

export const SUBJECTS = [
  'Mathematics', 'English Language', 'Integrated Science', 'Social Studies',
  'Creative & Technology Studies', 'Business Studies', 'History', 'Geography',
  'Civic Education', 'Biology', 'Chemistry', 'Physics'
];

export const CURRENCY = 'ZMW'; // Kwacha
